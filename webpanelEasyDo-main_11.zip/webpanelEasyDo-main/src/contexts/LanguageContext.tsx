import React, { createContext, useContext, useState, useEffect } from "react";
import { type Language } from "@/data/translations";
import { useGlobalFontLoader } from "@/hooks/useFontLoader";

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined,
);

export const useLanguageContext = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error(
      "useLanguageContext must be used within a LanguageProvider",
    );
  }
  return context;
};

interface LanguageProviderProps {
  children: React.ReactNode;
  defaultLanguage?: Language;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({
  children,
  defaultLanguage = "English",
}) => {
  const [language, setLanguageState] = useState<Language>(defaultLanguage);
  const { switchLanguage, isInitialized } = useGlobalFontLoader();

  // Load saved language from localStorage on mount
  useEffect(() => {
    const initializeLanguageAndFonts = async () => {
      try {
        const savedLanguage = localStorage.getItem(
          "selectedLanguage",
        ) as Language;
        const initialLanguage =
          savedLanguage && isValidLanguage(savedLanguage)
            ? savedLanguage
            : defaultLanguage;

        console.log(`🌍 Initializing language: ${initialLanguage}`);

        setLanguageState(initialLanguage);

        // Initialize fonts for the initial language with retry
        await switchLanguage(initialLanguage);

        console.log(`✅ Language context initialized for ${initialLanguage}`);
      } catch (error) {
        console.warn(`⚠️ Language initialization failed:`, error);
        // Fallback to default language
        setLanguageState(defaultLanguage);
        try {
          await switchLanguage(defaultLanguage);
        } catch (fallbackError) {
          console.warn(`⚠️ Fallback font loading also failed:`, fallbackError);
        }
      }
    };

    initializeLanguageAndFonts();
  }, [defaultLanguage, switchLanguage]);

  // Enhanced setLanguage function with font loading
  const setLanguage = async (newLanguage: Language) => {
    if (language === newLanguage) return;

    console.log(`🌐 Changing language from ${language} to ${newLanguage}`);

    try {
      // Set language state immediately for UI updates
      setLanguageState(newLanguage);
      localStorage.setItem("selectedLanguage", newLanguage);

      // Load fonts for the new language with error handling
      await switchLanguage(newLanguage);

      // Force a re-render to ensure new fonts are applied
      await new Promise((resolve) => {
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            resolve(void 0);
          });
        });
      });

      console.log(`✅ Language and fonts switched to ${newLanguage}`);
    } catch (error) {
      console.warn(`⚠️ Font loading failed for ${newLanguage}:`, error);
      // Language still changed, just fonts might not be optimal
    }
  };

  const value = {
    language,
    setLanguage,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

// Helper function to validate if a string is a valid Language
const isValidLanguage = (lang: string): lang is Language => {
  const validLanguages: Language[] = [
    "English",
    "Hindi",
    "Bengali",
    "Telugu",
    "Marathi",
    "Tamil",
    "Urdu",
    "Gujarati",
    "Kannada",
    "Odia",
    "Punjabi",
    "Malayalam",
  ];
  return validLanguages.includes(lang as Language);
};

export default LanguageProvider;
