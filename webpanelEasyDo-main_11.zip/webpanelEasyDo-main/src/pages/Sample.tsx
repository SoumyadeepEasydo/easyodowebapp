// Import the actual Sample component from Overview file
import Sample from "./Overview";

export default Sample;
